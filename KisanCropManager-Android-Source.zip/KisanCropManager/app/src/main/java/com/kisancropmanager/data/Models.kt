package com.kisancropmanager.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "farms")
data class FarmEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val areaAcres: Double = 0.0,
    val location: String = "",
    val notes: String = ""
)

@Entity(tableName = "plots")
data class PlotEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val farmId: Long,
    val name: String,
    val areaAcres: Double,
    val soilType: String = "",
    val irrigationType: String = "",
    val notes: String = ""
)

@Entity(tableName = "crop_cycles")
data class CropCycleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val plotId: Long,
    val cropName: String,
    val variety: String = "",
    val areaAcres: Double,
    val sowingDate: String,
    val expectedHarvestDate: String = "",
    val actualHarvestDate: String = "",
    val stage: String = "Land preparation",
    val expectedYieldKg: Double = 0.0,
    val notes: String = "",
    val isActive: Boolean = true
)

@Entity(tableName = "expenses")
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val cropCycleId: Long,
    val plotId: Long,
    val date: String,
    val category: String,
    val description: String,
    val quantity: Double = 0.0,
    val unit: String = "",
    val unitPrice: Double = 0.0,
    val amount: Double,
    val amountPaid: Double = 0.0,
    val paymentMethod: String = "",
    val billText: String = "",
    val notes: String = ""
) {
    val outstanding: Double get() = (amount - amountPaid).coerceAtLeast(0.0)
}

@Entity(tableName = "activity_entries")
data class ActivityEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val cropCycleId: Long,
    val plotId: Long,
    val date: String,
    val category: String,
    val title: String,
    val description: String = "",
    val quantity: Double = 0.0,
    val unit: String = "",
    val cost: Double = 0.0,
    val notes: String = ""
)

@Entity(tableName = "labour_entries")
data class LabourEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val cropCycleId: Long,
    val plotId: Long,
    val date: String,
    val activity: String,
    val workerCount: Int,
    val wagePerWorker: Double,
    val days: Double = 1.0,
    val amountPaid: Double = 0.0,
    val notes: String = ""
) {
    val totalCost: Double get() = workerCount * wagePerWorker * days
    val outstanding: Double get() = (totalCost - amountPaid).coerceAtLeast(0.0)
}

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val cropCycleId: Long,
    val title: String,
    val dueDate: String,
    val notes: String = "",
    val isCompleted: Boolean = false
)
