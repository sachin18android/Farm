package com.kisancropmanager.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface FarmDao {
    @Query("SELECT * FROM farms ORDER BY id DESC")
    fun farms(): Flow<List<FarmEntity>>
    @Insert suspend fun addFarm(item: FarmEntity): Long
    @Update suspend fun updateFarm(item: FarmEntity)

    @Query("SELECT * FROM plots ORDER BY id DESC")
    fun plots(): Flow<List<PlotEntity>>
    @Query("SELECT * FROM plots WHERE farmId = :farmId ORDER BY id DESC")
    fun plotsForFarm(farmId: Long): Flow<List<PlotEntity>>
    @Insert suspend fun addPlot(item: PlotEntity): Long
    @Update suspend fun updatePlot(item: PlotEntity)

    @Query("SELECT * FROM crop_cycles ORDER BY isActive DESC, id DESC")
    fun crops(): Flow<List<CropCycleEntity>>
    @Query("SELECT * FROM crop_cycles WHERE id = :id LIMIT 1")
    suspend fun cropById(id: Long): CropCycleEntity?
    @Insert suspend fun addCrop(item: CropCycleEntity): Long
    @Update suspend fun updateCrop(item: CropCycleEntity)

    @Query("SELECT * FROM expenses ORDER BY date DESC, id DESC")
    fun expenses(): Flow<List<ExpenseEntity>>
    @Query("SELECT * FROM expenses WHERE cropCycleId = :cropId ORDER BY date DESC, id DESC")
    fun expensesForCrop(cropId: Long): Flow<List<ExpenseEntity>>
    @Insert suspend fun addExpense(item: ExpenseEntity): Long
    @Update suspend fun updateExpense(item: ExpenseEntity)
    @Query("DELETE FROM expenses WHERE id = :id")
    suspend fun deleteExpense(id: Long)

    @Query("SELECT * FROM activity_entries ORDER BY date DESC, id DESC")
    fun activities(): Flow<List<ActivityEntity>>
    @Query("SELECT * FROM activity_entries WHERE cropCycleId = :cropId ORDER BY date DESC, id DESC")
    fun activitiesForCrop(cropId: Long): Flow<List<ActivityEntity>>
    @Insert suspend fun addActivity(item: ActivityEntity): Long

    @Query("SELECT * FROM labour_entries ORDER BY date DESC, id DESC")
    fun labourEntries(): Flow<List<LabourEntity>>
    @Insert suspend fun addLabour(item: LabourEntity): Long

    @Query("SELECT * FROM tasks ORDER BY isCompleted ASC, dueDate ASC")
    fun tasks(): Flow<List<TaskEntity>>
    @Insert suspend fun addTask(item: TaskEntity): Long
    @Update suspend fun updateTask(item: TaskEntity)

    @Query("SELECT COALESCE(SUM(amount), 0) FROM expenses")
    fun totalExpense(): Flow<Double>
    @Query("SELECT COALESCE(SUM(amountPaid), 0) FROM expenses")
    fun totalPaid(): Flow<Double>
    @Query("SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE cropCycleId = :cropId")
    fun cropExpenseTotal(cropId: Long): Flow<Double>
    @Query("SELECT COALESCE(SUM(workerCount * wagePerWorker * days), 0) FROM labour_entries")
    fun totalLabourCost(): Flow<Double>
    @Query("SELECT COALESCE(SUM(amountPaid), 0) FROM labour_entries")
    fun totalLabourPaid(): Flow<Double>
}
