package com.kisancropmanager

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Agriculture
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.withTransaction
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.kisancropmanager.data.*
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun today(): String = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date())
private fun money(v: Double): String = "₹" + String.format(Locale("en", "IN"), "%,.2f", v)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = AppDatabase.get(applicationContext)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(
                primary = androidx.compose.ui.graphics.Color(0xFF246B45),
                secondary = androidx.compose.ui.graphics.Color(0xFF8A6D32),
                surface = androidx.compose.ui.graphics.Color(0xFFF8FAF6)
            )) {
                val vm: FarmViewModel = viewModel(factory = FarmViewModel.factory(db))
                KisanApp(vm)
            }
        }
    }
}

class FarmViewModel(private val db: AppDatabase) : ViewModel() {
    private val dao = db.farmDao()
    val farms = dao.farms().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val plots = dao.plots().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val crops = dao.crops().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val expenses = dao.expenses().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val activities = dao.activities().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val labour = dao.labourEntries().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val tasks = dao.tasks().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val totalExpense = dao.totalExpense().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)
    val totalPaid = dao.totalPaid().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)
    val totalLabour = dao.totalLabourCost().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)
    val totalLabourPaid = dao.totalLabourPaid().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    fun addFarm(name: String, acres: String, location: String) = viewModelScope.launch {
        if (name.isBlank()) return@launch
        dao.addFarm(FarmEntity(name = name.trim(), areaAcres = acres.toDoubleOrNull() ?: 0.0, location = location.trim()))
    }
    fun addPlot(farmId: Long, name: String, acres: String, soil: String, irrigation: String) = viewModelScope.launch {
        if (name.isBlank() || acres.toDoubleOrNull() == null || acres.toDouble() <= 0) return@launch
        dao.addPlot(PlotEntity(farmId = farmId, name = name.trim(), areaAcres = acres.toDouble(), soilType = soil, irrigationType = irrigation))
    }
    fun addCrop(plotId: Long, name: String, variety: String, acres: String, sowing: String, expected: String) = viewModelScope.launch {
        if (name.isBlank() || acres.toDoubleOrNull() == null || acres.toDouble() <= 0) return@launch
        dao.addCrop(CropCycleEntity(plotId = plotId, cropName = name.trim(), variety = variety.trim(),
            areaAcres = acres.toDouble(), sowingDate = sowing.ifBlank { today() }, expectedHarvestDate = expected.trim()))
    }
    fun addExpense(crop: CropCycleEntity, date: String, category: String, description: String, amount: String, paid: String, notes: String) = viewModelScope.launch {
        val value = amount.toDoubleOrNull() ?: return@launch
        if (value < 0 || description.isBlank()) return@launch
        val paidValue = (paid.toDoubleOrNull() ?: 0.0).coerceIn(0.0, value)
        dao.addExpense(ExpenseEntity(cropCycleId = crop.id, plotId = crop.plotId, date = date.ifBlank { today() },
            category = category, description = description.trim(), amount = value, amountPaid = paidValue, notes = notes.trim()))
    }
    fun addActivity(crop: CropCycleEntity, date: String, category: String, title: String, description: String, cost: String) = viewModelScope.launch {
        val amount = cost.toDoubleOrNull() ?: 0.0
        if (title.isBlank()) return@launch
        dao.addActivity(ActivityEntity(cropCycleId = crop.id, plotId = crop.plotId, date = date.ifBlank { today() },
            category = category, title = title.trim(), description = description.trim(), cost = amount))
        // Activity cost is informational. Add a matching expense only if the user records it in Expenses,
        // preventing activity + expense double counting.
    }
    fun addLabour(crop: CropCycleEntity, date: String, activity: String, workers: String, wage: String, days: String, paid: String) = viewModelScope.launch {
        val n = workers.toIntOrNull() ?: return@launch
        val w = wage.toDoubleOrNull() ?: return@launch
        val d = days.toDoubleOrNull() ?: 1.0
        if (n <= 0 || w < 0 || d <= 0 || activity.isBlank()) return@launch
        val total = n * w * d
        val p = (paid.toDoubleOrNull() ?: 0.0).coerceIn(0.0, total)
        dao.addLabour(LabourEntity(cropCycleId = crop.id, plotId = crop.plotId, date = date.ifBlank { today() },
            activity = activity.trim(), workerCount = n, wagePerWorker = w, days = d, amountPaid = p))
    }
    fun addTask(cropId: Long, title: String, due: String, notes: String) = viewModelScope.launch {
        if (title.isNotBlank()) dao.addTask(TaskEntity(cropCycleId = cropId, title = title.trim(), dueDate = due.ifBlank { today() }, notes = notes))
    }
    fun toggleTask(task: TaskEntity) = viewModelScope.launch { dao.updateTask(task.copy(isCompleted = !task.isCompleted)) }
    fun setCropStage(crop: CropCycleEntity, stage: String) = viewModelScope.launch { dao.updateCrop(crop.copy(stage = stage)) }

    companion object {
        fun factory(db: AppDatabase) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = FarmViewModel(db) as T
        }
    }
}

private enum class Tab(val label: String) {
    HOME("Home"), CROPS("My Crops"), ADD("Add Entry"), CALENDAR("Calendar"), REPORTS("Reports")
}

@Composable
fun KisanApp(vm: FarmViewModel) {
    var tab by remember { mutableStateOf(Tab.HOME) }
    var dialog by remember { mutableStateOf("") }
    var selectedCropId by remember { mutableLongStateOf(0L) }
    var voiceDraft by remember { mutableStateOf("") }
    var billDraft by remember { mutableStateOf("") }
    val context = LocalContext.current
    val crops by vm.crops.collectAsState()
    val farms by vm.farms.collectAsState()
    val plots by vm.plots.collectAsState()
    val expenses by vm.expenses.collectAsState()
    val labour by vm.labour.collectAsState()
    val activities by vm.activities.collectAsState()
    val tasks by vm.tasks.collectAsState()
    val totalExpense by vm.totalExpense.collectAsState()
    val totalPaid by vm.totalPaid.collectAsState()
    val totalLabour by vm.totalLabour.collectAsState()
    val totalLabourPaid by vm.totalLabourPaid.collectAsState()

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
        if (spoken.isNotBlank()) { voiceDraft = spoken; dialog = "voice" }
    }
    val billPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            try {
                val image = InputImage.fromFilePath(context, uri)
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
                    .addOnSuccessListener { text -> billDraft = text.text; dialog = "bill" }
                    .addOnFailureListener { billDraft = "Could not read text from this image. Enter bill details manually."; dialog = "bill" }
            } catch (_: Exception) { billDraft = "Could not open image. Enter bill details manually."; dialog = "bill" }
        }
    }

    Scaffold(
        topBar = {
            TopAppBarCompat(
                title = "Kisan Crop Manager",
                subtitle = "Your farm, every rupee tracked"
            )
        },
        bottomBar = {
            NavigationBar {
                Tab.values().forEach { t ->
                    val icon = when (t) {
                        Tab.HOME -> Icons.Default.Home
                        Tab.CROPS -> Icons.Default.Spa
                        Tab.ADD -> Icons.Default.Add
                        Tab.CALENDAR -> Icons.Default.CalendarMonth
                        Tab.REPORTS -> Icons.Default.Assessment
                    }
                    NavigationBarItem(selected = tab == t, onClick = { tab = t },
                        icon = { Icon(icon, contentDescription = t.label) }, label = { Text(t.label) })
                }
            }
        },
        floatingActionButton = {
            if (tab == Tab.ADD) {
                ExtendedFloatingActionButton(onClick = {
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                        putExtra(RecognizerIntent.EXTRA_PROMPT, "अपनी खेती की जानकारी बोलें")
                    }
                    try { speechLauncher.launch(intent) } catch (_: Exception) { voiceDraft = "Speech recognition is not available on this device."; dialog = "voice" }
                }, icon = { Icon(Icons.Default.Mic, null) }, text = { Text("Speak in Hindi") })
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            when (tab) {
                Tab.HOME -> HomeScreen(farms.size, plots.size, crops, totalExpense, totalPaid, totalLabour, totalLabourPaid,
                    onAddFarm = { dialog = "farm" }, onAddPlot = { dialog = "plot" }, onAddCrop = { dialog = "crop" })
                Tab.CROPS -> CropsScreen(crops, plots, expenses, activities, labour,
                    onAddCrop = { dialog = "crop" }, onSelect = { selectedCropId = it; dialog = "cropDetails" },
                    onStage = { crop, stage -> vm.setCropStage(crop, stage) })
                Tab.ADD -> AddEntryScreen(crops, onExpense = { selectedCropId = it; dialog = "expense" },
                    onActivity = { selectedCropId = it; dialog = "activity" },
                    onLabour = { selectedCropId = it; dialog = "labour" },
                    onTask = { selectedCropId = it; dialog = "task" },
                    onScanBill = { billPicker.launch("image/*") })
                Tab.CALENDAR -> CalendarScreen(tasks, crops, onAdd = { selectedCropId = it; dialog = "task" }, onToggle = vm::toggleTask)
                Tab.REPORTS -> ReportsScreen(crops, plots, expenses, labour, totalExpense, totalPaid, totalLabour)
            }
        }
    }

    when (dialog) {
        "farm" -> FarmDialog(onDismiss = { dialog = "" }, onSave = { n, a, l -> vm.addFarm(n,a,l); dialog = "" })
        "plot" -> PlotDialog(farms, onDismiss = { dialog = "" }, onSave = { f,n,a,s,i -> vm.addPlot(f,n,a,s,i); dialog = "" })
        "crop" -> CropDialog(plots, onDismiss = { dialog = "" }, onSave = { p,n,v,a,s,e -> vm.addCrop(p,n,v,a,s,e); dialog = "" })
        "expense" -> {
            val crop = crops.firstOrNull { it.id == selectedCropId }
            if (crop != null) ExpenseDialog(crop, onDismiss = { dialog = "" }, onSave = { d,c,desc,a,p,n -> vm.addExpense(crop,d,c,desc,a,p,n); dialog = "" })
            else SimpleMessageDialog("Add a crop first", "Create a farm, plot, and crop before recording a crop expense.") { dialog = "" }
        }
        "activity" -> {
            val crop = crops.firstOrNull { it.id == selectedCropId }
            if (crop != null) ActivityDialog(crop, onDismiss = { dialog = "" }, onSave = { d,c,t,desc,cost -> vm.addActivity(crop,d,c,t,desc,cost); dialog = "" })
            else SimpleMessageDialog("Add a crop first", "Create a farm, plot, and crop before recording activities.") { dialog = "" }
        }
        "labour" -> {
            val crop = crops.firstOrNull { it.id == selectedCropId }
            if (crop != null) LabourDialog(crop, onDismiss = { dialog = "" }, onSave = { d,a,w,r,days,p -> vm.addLabour(crop,d,a,w,r,days,p); dialog = "" })
            else SimpleMessageDialog("Add a crop first", "Create a farm, plot, and crop before recording labour.") { dialog = "" }
        }
        "task" -> {
            val crop = crops.firstOrNull { it.id == selectedCropId }
            if (crop != null) TaskDialog(crop, onDismiss = { dialog = "" }, onSave = { t,d,n -> vm.addTask(crop.id,t,d,n); dialog = "" })
            else SimpleMessageDialog("Add a crop first", "Create a crop before scheduling a task.") { dialog = "" }
        }
        "voice" -> VoiceDraftDialog(voiceDraft, crops, onDismiss = { dialog = "" }, onSaveExpense = { cropId, amount, description ->
            val crop = crops.firstOrNull { it.id == cropId }
            if (crop != null) vm.addExpense(crop, today(), "Other", description.ifBlank { voiceDraft }, amount, "0", "Created from voice draft")
            dialog = ""
        })
        "bill" -> BillDraftDialog(billDraft, onDismiss = { dialog = "" })
        "cropDetails" -> {
            val crop = crops.firstOrNull { it.id == selectedCropId }
            if (crop != null) CropDetailsDialog(crop, plots.firstOrNull { it.id == crop.plotId }?.name ?: "Plot", expenses.filter { it.cropCycleId == crop.id }, activities.filter { it.cropCycleId == crop.id }, labour.filter { it.cropCycleId == crop.id }, onDismiss = { dialog = "" })
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TopAppBarCompat(title: String, subtitle: String) {
    CenterAlignedTopAppBar(title = {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.labelSmall)
        }
    })
}

@Composable
private fun HomeScreen(
    farmCount: Int, plotCount: Int, crops: List<CropCycleEntity>, totalExpense: Double, totalPaid: Double,
    totalLabour: Double, totalLabourPaid: Double, onAddFarm: () -> Unit, onAddPlot: () -> Unit, onAddCrop: () -> Unit
) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Farm overview", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("Farms", farmCount.toString(), Modifier.weight(1f))
                StatCard("Plots", plotCount.toString(), Modifier.weight(1f))
                StatCard("Active crops", crops.count { it.isActive }.toString(), Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("Crop expenses", money(totalExpense), Modifier.weight(1f))
                StatCard("Expense paid", money(totalPaid), Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("Labour cost", money(totalLabour), Modifier.weight(1f))
                StatCard("Labour paid", money(totalLabourPaid), Modifier.weight(1f))
            }
        }
        item { Text("Quick setup", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold) }
        item { Button(onClick = onAddFarm, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Agriculture, null); Spacer(Modifier.width(8.dp)); Text("Add farm") } }
        item { OutlinedButton(onClick = onAddPlot, modifier = Modifier.fillMaxWidth()) { Text("Add plot") } }
        item { OutlinedButton(onClick = onAddCrop, modifier = Modifier.fillMaxWidth()) { Text("Add crop cycle") } }
        item { Text("Active crop cycles", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold) }
        if (crops.isEmpty()) item { EmptyCard("No crops yet", "Start by adding a farm, a plot, and then a crop cycle.") }
        items(crops.take(6)) { crop ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text(crop.cropName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text("${crop.areaAcres} acres • ${crop.stage}")
                    Text("Sown: ${crop.sowingDate} • Harvest estimate: ${crop.expectedHarvestDate.ifBlank { "Not set" }}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun CropsScreen(
    crops: List<CropCycleEntity>, plots: List<PlotEntity>, expenses: List<ExpenseEntity>, activities: List<ActivityEntity>,
    labour: List<LabourEntity>, onAddCrop: () -> Unit, onSelect: (Long) -> Unit, onStage: (CropCycleEntity, String) -> Unit
) {
    var filter by remember { mutableStateOf("") }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("My crops", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item { OutlinedTextField(filter, { filter = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Search crop or plot") }, singleLine = true) }
        item { Button(onClick = onAddCrop, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Text(" Add crop cycle") } }
        val visible = crops.filter { it.cropName.contains(filter, true) || (plots.firstOrNull { p -> p.id == it.plotId }?.name?.contains(filter, true) == true) }
        if (visible.isEmpty()) item { EmptyCard("No matching crops", "Add a crop cycle to begin tracking its lifecycle and investment.") }
        items(visible) { crop ->
            val plotName = plots.firstOrNull { it.id == crop.plotId }?.name ?: "Plot"
            val cost = expenses.filter { it.cropCycleId == crop.id }.sumOf { it.amount } + labour.filter { it.cropCycleId == crop.id }.sumOf { it.totalCost }
            Card(onClick = { onSelect(crop.id) }, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(crop.cropName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("$plotName • ${crop.areaAcres} acres")
                        }
                        Text(money(cost), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                    Text("Stage: ${crop.stage} • Sowing: ${crop.sowingDate}")
                    var expanded by remember { mutableStateOf(false) }
                    Box {
                        OutlinedButton(onClick = { expanded = true }) { Text("Update stage") }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            listOf("Land preparation","Nursery","Sowing","Transplantation","Establishment","Vegetative growth","Flowering","Fruiting","Maturity","Harvesting","Crop completed").forEach { stage ->
                                DropdownMenuItem(text = { Text(stage) }, onClick = { onStage(crop, stage); expanded = false })
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AddEntryScreen(
    crops: List<CropCycleEntity>, onExpense: (Long) -> Unit, onActivity: (Long) -> Unit, onLabour: (Long) -> Unit,
    onTask: (Long) -> Unit, onScanBill: () -> Unit
) {
    var selected by remember(crops) { mutableStateOf(crops.firstOrNull()?.id ?: 0L) }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Add an entry", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item { Text("Select the crop this record belongs to.") }
        item {
            var expanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                OutlinedTextField(
                    value = crops.firstOrNull { it.id == selected }?.let { "${it.cropName} • ${it.sowingDate}" } ?: "No crop available",
                    onValueChange = {}, readOnly = true, label = { Text("Crop cycle") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    crops.forEach { c -> DropdownMenuItem(text = { Text("${c.cropName} • ${c.sowingDate}") }, onClick = { selected = c.id; expanded = false }) }
                }
            }
        }
        item { Button(onClick = { if (selected != 0L) onExpense(selected) }, modifier = Modifier.fillMaxWidth()) { Text("＋  Add expense") } }
        item { OutlinedButton(onClick = { if (selected != 0L) onLabour(selected) }, modifier = Modifier.fillMaxWidth()) { Text("👷  Record labour") } }
        item { OutlinedButton(onClick = { if (selected != 0L) onActivity(selected) }, modifier = Modifier.fillMaxWidth()) { Text("🌱  Record activity / fertilizer / spray") } }
        item { OutlinedButton(onClick = { if (selected != 0L) onTask(selected) }, modifier = Modifier.fillMaxWidth()) { Text("📅  Schedule a task") } }
        item { OutlinedButton(onClick = onScanBill, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.CameraAlt, null); Spacer(Modifier.width(8.dp)); Text("Scan bill from photo") } }
        item { Text("Tip: Record a purchase as an expense. Record the field activity separately if you also want a timeline entry. Activity costs are informational and are not automatically added to investment totals.", style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
private fun CalendarScreen(tasks: List<TaskEntity>, crops: List<CropCycleEntity>, onAdd: (Long) -> Unit, onToggle: (TaskEntity) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Farm calendar", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item { Text("Plan irrigation, weeding, inspections, and other work.") }
        if (crops.isNotEmpty()) item { Button(onClick = { onAdd(crops.first().id) }, modifier = Modifier.fillMaxWidth()) { Text("＋ Schedule task for ${crops.first().cropName}") } }
        if (tasks.isEmpty()) item { EmptyCard("No tasks scheduled", "Schedule your next farming activity here.") }
        items(tasks) { task ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = task.isCompleted, onCheckedChange = { onToggle(task) })
                    Column(Modifier.weight(1f)) {
                        Text(task.title, fontWeight = FontWeight.SemiBold)
                        Text("Due: ${task.dueDate}")
                        if (task.notes.isNotBlank()) Text(task.notes, style = MaterialTheme.typography.bodySmall)
                    }
                    Text(if (task.isCompleted) "Done" else "Pending", color = if (task.isCompleted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary)
                }
            }
        }
    }
}

@Composable
private fun ReportsScreen(
    crops: List<CropCycleEntity>, plots: List<PlotEntity>, expenses: List<ExpenseEntity>, labour: List<LabourEntity>,
    totalExpense: Double, totalPaid: Double, totalLabour: Double
) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Investment reports", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item { StatCard("Recorded expenses", money(totalExpense), Modifier.fillMaxWidth()) }
        item { StatCard("Expense outstanding", money((totalExpense - totalPaid).coerceAtLeast(0.0)), Modifier.fillMaxWidth()) }
        item { StatCard("Labour cost", money(totalLabour), Modifier.fillMaxWidth()) }
        item { Text("Crop-wise cost", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold) }
        if (crops.isEmpty()) item { EmptyCard("No data yet", "Add crops and expenses to see reports.") }
        items(crops) { crop ->
            val expenseCost = expenses.filter { it.cropCycleId == crop.id }.sumOf { it.amount }
            val labourCost = labour.filter { it.cropCycleId == crop.id }.sumOf { it.totalCost }
            val total = expenseCost + labourCost
            val plot = plots.firstOrNull { it.id == crop.plotId }?.name ?: "Plot"
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text("${crop.cropName} • $plot", fontWeight = FontWeight.Bold)
                    Text("Total recorded crop cost: ${money(total)}")
                    Text("Expense records: ${money(expenseCost)} • Labour: ${money(labourCost)}")
                    Text("Cost per acre: ${if (crop.areaAcres > 0) money(total / crop.areaAcres) else "N/A"}")
                }
            }
        }
        item { Text("Accounting note: labour costs are included in crop cost from the labour register. Do not also enter the same labour amount as an expense, or it will be counted twice.", style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) { Column(Modifier.padding(12.dp)) { Text(label, style = MaterialTheme.typography.labelMedium); Spacer(Modifier.height(4.dp)); Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) } }
}
@Composable private fun EmptyCard(title: String, body: String) {
    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp)) { Text(title, fontWeight = FontWeight.Bold); Text(body, style = MaterialTheme.typography.bodyMedium) } }
}

@Composable
private fun FarmDialog(onDismiss: () -> Unit, onSave: (String, String, String) -> Unit) {
    var name by remember { mutableStateOf("") }; var acres by remember { mutableStateOf("") }; var location by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Add farm") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("Farm name *") }, singleLine = true)
            OutlinedTextField(acres, { acres = it }, label = { Text("Total area (acres)") }, singleLine = true)
            OutlinedTextField(location, { location = it }, label = { Text("Village / location") }, singleLine = true)
        }
    }, confirmButton = { TextButton(onClick = { onSave(name, acres, location) }) { Text("Save") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
private fun PlotDialog(farms: List<FarmEntity>, onDismiss: () -> Unit, onSave: (Long, String, String, String, String) -> Unit) {
    var farmId by remember(farms) { mutableLongStateOf(farms.firstOrNull()?.id ?: 0L) }
    var name by remember { mutableStateOf("") }; var acres by remember { mutableStateOf("") }; var soil by remember { mutableStateOf("") }; var irrigation by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Add plot") }, text = {
        Column(Modifier.heightIn(max = 450.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (farms.isEmpty()) Text("Add a farm first.")
            else {
                var expanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                    OutlinedTextField(farms.firstOrNull { it.id == farmId }?.name ?: "Choose farm", {}, readOnly = true,
                        label = { Text("Farm") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        farms.forEach { f -> DropdownMenuItem(text = { Text(f.name) }, onClick = { farmId = f.id; expanded = false }) }
                    }
                }
            }
            OutlinedTextField(name, { name = it }, label = { Text("Plot name *") }, singleLine = true)
            OutlinedTextField(acres, { acres = it }, label = { Text("Area in acres *") }, singleLine = true)
            OutlinedTextField(soil, { soil = it }, label = { Text("Soil type") }, singleLine = true)
            OutlinedTextField(irrigation, { irrigation = it }, label = { Text("Irrigation type") }, singleLine = true)
        }
    }, confirmButton = { TextButton(onClick = { if (farmId != 0L) onSave(farmId, name, acres, soil, irrigation) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
private fun CropDialog(plots: List<PlotEntity>, onDismiss: () -> Unit, onSave: (Long, String, String, String, String, String) -> Unit) {
    var plotId by remember(plots) { mutableLongStateOf(plots.firstOrNull()?.id ?: 0L) }
    var name by remember { mutableStateOf("") }; var variety by remember { mutableStateOf("") }; var acres by remember { mutableStateOf("") }
    var sowing by remember { mutableStateOf(today()) }; var harvest by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Add crop cycle") }, text = {
        Column(Modifier.heightIn(max = 470.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (plots.isEmpty()) Text("Add a farm and plot first.")
            else {
                var expanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                    OutlinedTextField(plots.firstOrNull { it.id == plotId }?.name ?: "Choose plot", {}, readOnly = true,
                        label = { Text("Plot") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        plots.forEach { p -> DropdownMenuItem(text = { Text("${p.name} • ${p.areaAcres} acres") }, onClick = { plotId = p.id; expanded = false }) }
                    }
                }
            }
            OutlinedTextField(name, { name = it }, label = { Text("Crop name *") }, singleLine = true)
            OutlinedTextField(variety, { variety = it }, label = { Text("Variety") }, singleLine = true)
            OutlinedTextField(acres, { acres = it }, label = { Text("Cultivated area (acres) *") }, singleLine = true)
            OutlinedTextField(sowing, { sowing = it }, label = { Text("Sowing / plantation date") }, singleLine = true)
            OutlinedTextField(harvest, { harvest = it }, label = { Text("Expected harvest date") }, singleLine = true)
        }
    }, confirmButton = { TextButton(onClick = { if (plotId != 0L) onSave(plotId, name, variety, acres, sowing, harvest) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
private fun ExpenseDialog(crop: CropCycleEntity, onDismiss: () -> Unit, onSave: (String, String, String, String, String, String) -> Unit) {
    var date by remember { mutableStateOf(today()) }; var category by remember { mutableStateOf("Fertilizer") }; var desc by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }; var paid by remember { mutableStateOf("0") }; var notes by remember { mutableStateOf("") }
    val categories = listOf("Seeds", "Nursery", "Plantation", "Land preparation", "Labour", "Fertilizer", "Pesticide", "Fungicide", "Herbicide", "Irrigation", "Diesel / fuel", "Machinery", "Harvesting", "Transport", "Other")
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Add expense • ${crop.cropName}") }, text = {
        Column(Modifier.heightIn(max = 500.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(date, { date = it }, label = { Text("Date (DD-MM-YYYY)") }, singleLine = true)
            var expanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                OutlinedTextField(category, {}, readOnly = true, label = { Text("Category") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) { categories.forEach { DropdownMenuItem(text = { Text(it) }, onClick = { category = it; expanded = false }) } }
            }
            OutlinedTextField(desc, { desc = it }, label = { Text("Description *") })
            OutlinedTextField(amount, { amount = it }, label = { Text("Total amount (₹) *") }, singleLine = true)
            OutlinedTextField(paid, { paid = it }, label = { Text("Amount paid (₹)") }, singleLine = true)
            OutlinedTextField(notes, { notes = it }, label = { Text("Notes") })
        }
    }, confirmButton = { TextButton(onClick = { onSave(date, category, desc, amount, paid, notes) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
private fun ActivityDialog(crop: CropCycleEntity, onDismiss: () -> Unit, onSave: (String, String, String, String, String) -> Unit) {
    var date by remember { mutableStateOf(today()) }; var category by remember { mutableStateOf("Fertilizer application") }
    var title by remember { mutableStateOf("") }; var description by remember { mutableStateOf("") }; var cost by remember { mutableStateOf("0") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Record activity • ${crop.cropName}") }, text = {
        Column(Modifier.heightIn(max = 450.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(date, { date = it }, label = { Text("Date") }, singleLine = true)
            OutlinedTextField(category, { category = it }, label = { Text("Category") }, singleLine = true)
            OutlinedTextField(title, { title = it }, label = { Text("Activity title *") })
            OutlinedTextField(description, { description = it }, label = { Text("Description / quantity") })
            OutlinedTextField(cost, { cost = it }, label = { Text("Cost for timeline only (₹)") }, singleLine = true)
            Text("To ensure accurate totals, record costs in Add Expense or Labour. This activity cost is not included in investment totals.", style = MaterialTheme.typography.bodySmall)
        }
    }, confirmButton = { TextButton(onClick = { onSave(date, category, title, description, cost) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
private fun LabourDialog(crop: CropCycleEntity, onDismiss: () -> Unit, onSave: (String, String, String, String, String, String) -> Unit) {
    var date by remember { mutableStateOf(today()) }; var activity by remember { mutableStateOf("Weeding") }; var workers by remember { mutableStateOf("1") }
    var wage by remember { mutableStateOf("500") }; var days by remember { mutableStateOf("1") }; var paid by remember { mutableStateOf("0") }
    val total = (workers.toIntOrNull() ?: 0) * (wage.toDoubleOrNull() ?: 0.0) * (days.toDoubleOrNull() ?: 1.0)
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Record labour • ${crop.cropName}") }, text = {
        Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(date, { date = it }, label = { Text("Date") }, singleLine = true)
            OutlinedTextField(activity, { activity = it }, label = { Text("Work performed") })
            OutlinedTextField(workers, { workers = it }, label = { Text("Number of workers") }, singleLine = true)
            OutlinedTextField(wage, { wage = it }, label = { Text("Wage per worker (₹)") }, singleLine = true)
            OutlinedTextField(days, { days = it }, label = { Text("Days (1 or 0.5)") }, singleLine = true)
            Text("Calculated labour cost: ${money(total)}", fontWeight = FontWeight.Bold)
            OutlinedTextField(paid, { paid = it }, label = { Text("Amount paid (₹)") }, singleLine = true)
            Text("Outstanding: ${money((total - (paid.toDoubleOrNull() ?: 0.0)).coerceAtLeast(0.0))}")
        }
    }, confirmButton = { TextButton(onClick = { onSave(date, activity, workers, wage, days, paid) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
private fun TaskDialog(crop: CropCycleEntity, onDismiss: () -> Unit, onSave: (String, String, String) -> Unit) {
    var title by remember { mutableStateOf("") }; var date by remember { mutableStateOf(today()) }; var notes by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Schedule task • ${crop.cropName}") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(title, { title = it }, label = { Text("Task *") })
            OutlinedTextField(date, { date = it }, label = { Text("Due date (DD-MM-YYYY)") })
            OutlinedTextField(notes, { notes = it }, label = { Text("Notes") })
        }
    }, confirmButton = { TextButton(onClick = { onSave(title, date, notes) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
private fun VoiceDraftDialog(text: String, crops: List<CropCycleEntity>, onDismiss: () -> Unit, onSaveExpense: (Long, String, String) -> Unit) {
    var transcript by remember(text) { mutableStateOf(text) }
    var amount by remember { mutableStateOf(Regex("(\\d+(?:[.,]\\d{1,2})?)\\s*(?:रुपये|रुपया|rupees|rs|₹)", RegexOption.IGNORE_CASE).find(text)?.groupValues?.get(1)?.replace(",", "") ?: "") }
    var cropId by remember(crops) { mutableLongStateOf(crops.firstOrNull()?.id ?: 0L) }
    var expanded by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Voice entry — review draft") }, text = {
        Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Check the transcription, crop, and amount before saving.")
            OutlinedTextField(transcript, { transcript = it }, label = { Text("What you said") })
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                OutlinedTextField(
                    value = crops.firstOrNull { it.id == cropId }?.let { "${it.cropName} • ${it.sowingDate}" } ?: "Choose crop",
                    onValueChange = {}, readOnly = true, label = { Text("Crop cycle") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    crops.forEach { c -> DropdownMenuItem(text = { Text("${c.cropName} • ${c.sowingDate}") }, onClick = { cropId = c.id; expanded = false }) }
                }
            }
            OutlinedTextField(amount, { amount = it }, label = { Text("Amount (₹)") }, singleLine = true)
            Text("Voice recognition may misread crop names, dates, quantities, or amounts. This MVP saves the transcript as an expense description; verify and edit the details before confirming.", style = MaterialTheme.typography.bodySmall)
        }
    }, confirmButton = { TextButton(enabled = cropId != 0L && amount.toDoubleOrNull() != null, onClick = { onSaveExpense(cropId, amount, transcript) }) { Text("Save as expense") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
private fun BillDraftDialog(text: String, onDismiss: () -> Unit) {
    var edited by remember(text) { mutableStateOf(text) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Bill OCR — review text") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Text extracted from the selected bill. OCR may be inaccurate; copy the confirmed amount into an expense record.")
            OutlinedTextField(edited, { edited = it }, modifier = Modifier.fillMaxWidth().height(250.dp), label = { Text("Extracted text") })
        }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } })
}

@Composable
private fun CropDetailsDialog(
    crop: CropCycleEntity, plotName: String, expenses: List<ExpenseEntity>, activities: List<ActivityEntity>, labour: List<LabourEntity>, onDismiss: () -> Unit
) {
    val totalExpense = expenses.sumOf { it.amount }
    val totalLabour = labour.sumOf { it.totalCost }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("${crop.cropName} • $plotName") }, text = {
        Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("${crop.areaAcres} acres • ${crop.stage}")
            Text("Sowing: ${crop.sowingDate}")
            Text("Expected harvest: ${crop.expectedHarvestDate.ifBlank { "Not set" }}")
            HorizontalDivider()
            Text("Investment: ${money(totalExpense + totalLabour)}", fontWeight = FontWeight.Bold)
            Text("Expenses: ${money(totalExpense)}")
            Text("Labour: ${money(totalLabour)}")
            Text("Cost per acre: ${if (crop.areaAcres > 0) money((totalExpense + totalLabour) / crop.areaAcres) else "N/A"}")
            HorizontalDivider()
            Text("Activity timeline", fontWeight = FontWeight.Bold)
            val rows = (expenses.map { Triple(it.date, it.category, "${it.description} • ${money(it.amount)}") } +
                activities.map { Triple(it.date, it.category, it.title) } +
                labour.map { Triple(it.date, "Labour", "${it.activity} • ${it.workerCount} workers • ${money(it.totalCost)}") }).sortedByDescending { it.first }
            if (rows.isEmpty()) Text("No activities or expenses recorded yet.")
            rows.forEach { row -> Text("${row.first} — ${row.second}\n${row.third}", style = MaterialTheme.typography.bodyMedium); HorizontalDivider() }
        }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } })
}

@Composable
private fun SimpleMessageDialog(title: String, message: String, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) }, text = { Text(message) },
        confirmButton = { TextButton(onClick = onDismiss) { Text("OK") } })
}
