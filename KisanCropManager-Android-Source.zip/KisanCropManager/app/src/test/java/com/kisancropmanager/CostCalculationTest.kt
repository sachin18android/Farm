package com.kisancropmanager

import org.junit.Assert.assertEquals
import org.junit.Test

class CostCalculationTest {
    @Test fun labourCostIncludesWorkersWageAndDays() {
        val workers = 5
        val wage = 500.0
        val days = 1.0
        assertEquals(2500.0, workers * wage * days, 0.001)
    }

    @Test fun fertilizerConsumedCostIsProportional() {
        val purchaseKg = 50.0
        val purchaseCost = 1350.0
        val usedKg = 20.0
        assertEquals(540.0, purchaseCost / purchaseKg * usedKg, 0.001)
    }

    @Test fun outstandingIsNotNegative() {
        val amount = 1000.0
        val paid = 1200.0
        assertEquals(0.0, (amount - paid).coerceAtLeast(0.0), 0.001)
    }
}
